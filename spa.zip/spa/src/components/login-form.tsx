"use client";

import { GalleryVerticalEnd } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { type ComponentProps, type FormEvent, useTransition } from "react";
import { loginAction } from "@/actions/login.action";
import { Button } from "@/components/ui/button";
import {
	Field,
	FieldGroup,
	FieldLabel,
	FieldSeparator,
} from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export function LoginForm({ className, ...props }: ComponentProps<"div">) {
	const [pending, startTransition] = useTransition();
	const router = useRouter();

	const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		startTransition(async () => {
			const response = await loginAction(new FormData(event.currentTarget));

			if (!response.status) {
				alert(response.message);
				return;
			}

			router.push("/catalog");
		});
	};

	return (
		<div
			className={cn("flex flex-col gap-4 sm:gap-6 w-full", className)}
			{...props}
		>
			<form
				className="border rounded-lg sm:rounded-xl p-4 sm:p-6 max-w-md w-full mx-auto bg-white shadow-sm sm:shadow-md"
				onSubmit={handleSubmit}
			>
				<FieldGroup className="space-y-4 sm:space-y-6">
					{/* Header */}
					<div className="flex flex-col items-center gap-3 sm:gap-4 text-center">
						<Link
							href="#!"
							className="flex flex-col items-center gap-2 font-medium"
						>
							<div className="flex size-10 sm:size-12 items-center justify-center rounded-lg bg-primary/10">
								<GalleryVerticalEnd className="size-6 sm:size-7 text-primary" />
							</div>
							<span className="sr-only">FAST-Food</span>
						</Link>

						<div className="space-y-1 sm:space-y-2">
							<h1 className="text-xl sm:text-2xl font-bold text-gray-900">
								Добро пожаловать в FAST-Food
							</h1>
							<p className="text-sm sm:text-base text-gray-600">
								Войдите в систему для продолжения
							</p>
						</div>
					</div>

					{/* Email Field */}
					<Field>
						<FieldLabel htmlFor="email" className="text-sm sm:text-base">
							Электронная почта
						</FieldLabel>
						<Input
							id="email"
							type="email"
							placeholder="admin@example.com"
							required
							name="email"
							className="h-10 sm:h-11 text-sm sm:text-base"
							disabled={pending}
						/>
					</Field>

					{/* Submit Button */}
					<Field>
						<Button
							type="submit"
							className="w-full h-10 sm:h-11 text-sm sm:text-base font-medium"
							disabled={pending}
						>
							{pending ? "Вход..." : "Войти в систему"}
						</Button>
					</Field>

					{/* Separator */}
					<FieldSeparator className="text-xs sm:text-sm">
						Или войдите с помощью
					</FieldSeparator>

					{/* Social Buttons */}
					<Field className="grid grid-cols-1 xs:grid-cols-2 gap-3 sm:gap-4">
						<Button
							variant="outline"
							type="button"
							className="h-10 sm:h-11 text-xs sm:text-sm"
							disabled={pending}
						>
							<svg
								xmlns="http://www.w3.org/2000/svg"
								viewBox="0 0 24 24"
								className="size-4 sm:size-5 mr-2"
							>
								<path
									d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"
									fill="currentColor"
								/>
							</svg>
							Apple
						</Button>
						<Button
							variant="outline"
							type="button"
							className="h-10 sm:h-11 text-xs sm:text-sm"
							disabled={pending}
						>
							<svg
								xmlns="http://www.w3.org/2000/svg"
								viewBox="0 0 24 24"
								className="size-4 sm:size-5 mr-2"
							>
								<path
									d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z"
									fill="currentColor"
								/>
							</svg>
							Google
						</Button>
					</Field>

					{/* Additional Info */}
					<div className="text-center">
						<p className="text-xs sm:text-sm text-gray-500">
							Продолжая, вы соглашаетесь с нашими{" "}
							<Link href="#!" className="text-primary hover:underline">
								Условиями использования
							</Link>{" "}
							и{" "}
							<Link href="#!" className="text-primary hover:underline">
								Политикой конфиденциальности
							</Link>
						</p>
					</div>
				</FieldGroup>
			</form>
		</div>
	);
}
