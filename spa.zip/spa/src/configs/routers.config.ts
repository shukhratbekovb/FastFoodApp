export const RoutersConfig = {
	login: "/login",
	catalog: "/catalog",
	cooking: "/cooking",
};
