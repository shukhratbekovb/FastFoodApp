const Page = async () => {
	return <section />
};

export default Page;
